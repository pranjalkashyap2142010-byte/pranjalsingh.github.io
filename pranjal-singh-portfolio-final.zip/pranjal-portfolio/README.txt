PRANJAL SINGH — PERSONAL PORTFOLIO
==================================

FILES
- index.html: complete responsive portfolio website
- assets/photo-01.jpg through photo-09.jpg: your 9 uploaded photos, optimized for web
- assets/final-video.mp4: add your edited video here (not included yet because the video has not been uploaded in this chat)

PUBLISH ON GITHUB PAGES FROM IPHONE
1. Open your repository on github.com in Safari.
2. Upload index.html and the assets folder with all 9 photo files. Keep the folder structure exactly as it is.
   On mobile GitHub, use Add file > Upload files if available. If uploading a folder is not offered, upload the 9 images into an assets folder first, then upload index.html to the repository root.
3. Upload your edited video into the assets folder and name it final-video.mp4. If the video is large, consider compressing it first; GitHub has file-size limits.
4. Open repository Settings > Pages.
5. Under Build and deployment, select Deploy from a branch, branch main, folder /(root), then Save.
6. Wait for deployment and open https://pranjalsingh.github.io/ . This address assumes the GitHub username is pranjalsingh. If your account username differs, the Pages URL may differ; check Settings > Pages for the published URL.

GOOGLE INDEXING
1. Open Google Search Console: https://search.google.com/search-console/
2. Add the published website URL and follow the verification instructions.
3. Use URL Inspection for the homepage and request indexing.
4. Indexing and Knowledge Panels are not guaranteed or instant.

NOTES
- The website is silent by default. The final video player only plays when the visitor taps play.
- Use only music you own or have permission/licensing to publish.
- Social links are set to the handles supplied by you.
- Update the canonical URL in index.html if your final GitHub Pages URL differs.

Contact details included in the website: +91 63934 23660 and pranjalkashyap2142020@gmail.com. These are public on the site; only publish them if you are comfortable with that.


LATEST UPDATE
- Final video is included at assets/final-video.mp4.
- Contact section includes the supplied phone and email.
- Upload the entire pranjal-portfolio folder contents (index.html and assets folder) to the root of your GitHub Pages repository.
